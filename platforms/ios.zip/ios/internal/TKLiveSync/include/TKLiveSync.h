//
//  TKLiveSync.h
//  TKLiveSync
//
//  Created by Tsvetan Raikov on 6/16/16.
//  Copyright © 2016 Telerik. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TKLiveSync.
FOUNDATION_EXPORT double TKLiveSyncVersionNumber;

//! Project version string for TKLiveSync.
FOUNDATION_EXPORT const unsigned char TKLiveSyncVersionString[];

void TNSInitializeLiveSync();
