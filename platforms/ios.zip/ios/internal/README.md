The contents of this folder is specific for the current version of the runtime.
It will be wiped and replaced on each platform update.
