var applicationModule = require("application");
applicationModule.start({ moduleName: "main-page" });
